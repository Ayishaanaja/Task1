package com.example.web.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.example.web.bean.FlightBean;

@Repository
public class AdministratorDAO {
	@Autowired
	private JdbcTemplate jdbcTemplate;
	public int addFlight(FlightBean flight) {
		return jdbcTemplate.update("insert into flight values('"+flight.getFlightID()+"','"+flight.getFlightName()+"',"+flight.getSeatingCapacity()+","+flight.getReservationCapacity()+")");
	}
	

}
