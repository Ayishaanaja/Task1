//hierarchical inheritance which extends to Add and Sub
package inheritence;

public class Numbers {
int a=200;
int b=175;
}
