package weekk3;

public class Record {
record Product(String name,double price) {}
public static void main(String[] args) {
	Product product = new Product("LapTop",50000.00);
	System.out.println(product.name()+" "+product.price());
}
}
