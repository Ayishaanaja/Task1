package weekk3;

public class TextBlock {
public static void main(String[] args) {
	String tb = """
			{
			status:success",
			"code:100"
			}
			""";
	System.out.println(tb);
}
}
