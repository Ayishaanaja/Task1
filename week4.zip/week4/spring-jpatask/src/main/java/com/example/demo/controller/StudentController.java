package com.example.demo.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import com.example.demo.bean.Student;
import com.example.demo.dao.StudentRepository;

@Controller
@RequestMapping("/student")
public class StudentController {

    @Autowired
    private StudentRepository repo;

    @GetMapping("/form")
    public String loadForm() {
        return "addStudent"; 
    }

    @PostMapping("/save")
    public String saveStudent(@RequestParam int id,
                              @RequestParam String name,
                              @RequestParam String course) {

        Student s = new Student();
        s.setId(id);
        s.setName(name);
        s.setCourse(course);

        repo.save(s);

        return "success";  
    }
}
