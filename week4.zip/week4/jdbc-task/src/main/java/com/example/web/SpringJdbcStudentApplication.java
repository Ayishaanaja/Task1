package com.example.web;

import com.example.web.bean.StudentBean;
import com.example.web.service.StudentService;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import java.util.List;

@SpringBootApplication
public class SpringJdbcStudentApplication {

    public static void main(String[] args) {
        
        ConfigurableApplicationContext ctx = SpringApplication.run(SpringJdbcStudentApplication.class, args);
        StudentService eserv = ctx.getBean(StudentService.class);

        int i;

        StudentBean s1 = new StudentBean(101, "Karthik", "CSE");
        i = eserv.addStudent(s1);
        System.out.println(i + " record inserted successfully...");

        StudentBean s2 = new StudentBean(102, "Vijay", "ECE");
        i = eserv.addStudent(s2);
        System.out.println(i + " record inserted successfully...");

        System.out.println("--- Student List ---");
        List<StudentBean> all = eserv.selectAll();

        for (StudentBean e : all) {
            System.out.println(e.getId() + " " + e.getName() + " " + e.getCourse());
        }

        ctx.close();
    }
}