package com.example.web.service;

import com.example.web.bean.StudentBean;
import com.example.web.dao.StudentDao;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service // Tells Spring this is a Service class
public class StudentService {

    @Autowired // Spring automatically connects the DAO
    private StudentDao studentDao;

    public int addStudent(StudentBean s) {
        return studentDao.addStudent(s);
    }

    public List<StudentBean> selectAll() {
        return studentDao.getStudents();
    }
}
