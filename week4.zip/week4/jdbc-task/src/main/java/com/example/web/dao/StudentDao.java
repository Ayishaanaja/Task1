package com.example.web.dao;

import com.example.web.bean.StudentBean;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


@Repository 
public class StudentDao {

    @Autowired 
    private JdbcTemplate jdbcTemplate;

    public int addStudent(StudentBean s) {
        String sql = "INSERT INTO student (id, name, course) VALUES (?, ?, ?)";
        return jdbcTemplate.update(sql, s.getId(), s.getName(), s.getCourse());
    }

    public List<StudentBean> getStudents() {
        String sql = "SELECT * FROM student";
        return jdbcTemplate.query(sql, new RowMapper<StudentBean>() {
            @Override
            public StudentBean mapRow(ResultSet rs, int rowNum) throws SQLException {
                StudentBean s = new StudentBean();
                s.setId(rs.getInt("id"));
                s.setName(rs.getString("name"));
                s.setCourse(rs.getString("course"));
                return s;
            }
        });
    }
}
