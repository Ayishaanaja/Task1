package com.example;

public class MessageService {
    public String getMessage() {
        return "Hello from MessageService!";
    }
}
