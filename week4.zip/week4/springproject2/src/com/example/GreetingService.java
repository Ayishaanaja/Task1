package com.example;

public class GreetingService {

    public String getMessage() {
        return "Hello from Spring Console App!";
    }
}
